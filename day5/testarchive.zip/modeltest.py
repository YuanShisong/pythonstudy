
#
print('module test')

def model():
    print('model method')